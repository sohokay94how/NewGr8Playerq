﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using C1.Win.C1InputPanel;

namespace ControlExplorer.InputPanel
{
    public partial class Overview : C1DemoForm
    {
        public Overview()
        {
            InitializeComponent();
        }

        private void Overview_Load(object sender, EventArgs e)
        {
            AddProperty("VisualStyle", c1InputPanel1);
        }
    }
}
